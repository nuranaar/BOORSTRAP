# 16.09.2018

 Bootstrap
 
 - https://getbootstrap.com/
 
  # Tapsiriq
  
  - https://getbootstrap.com/docs/4.1/examples/album/
  - https://blackrockdigital.github.io/startbootstrap-freelancer/
  
  Bu Iki template islemelisiniz
